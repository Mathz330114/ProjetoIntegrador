# AI Chat

To build and run the project:

```
git clone https://github.com/alejandro-du/vaadin-ai-chat.git
cd vaadin-ai-chat
mvn package
java -jar target/vaadin-chat-1.0-SNAPSHOT.jar
```

Go to http://localhost:8080
